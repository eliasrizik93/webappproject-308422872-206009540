
angular.module('BrowseBooksAndProfileModule',[])
	.controller('BrowseBooksAndProfileController', ['$scope','$http', function($scope,$http) {
		$scope.bookname="";
		$scope.bookname2="";
		$scope.bookname3="";
		$scope.bookname4="";
		$scope.likes = 0 ;
		$scope.myVar = true;
		$scope.myVar2 = false;
		$scope.admin = false;
		$scope.normalUser= false;
		
		

		//get the session
		$scope.userSession = JSON.parse(sessionStorage.getItem('user'));
		
		//if session is admin then change the page to suit with the admin Functions
		if($scope.userSession.username == "admin") 
			{
				$scope.admin = true;
				$scope.normalUser = false;
			}
		
		//get all Books
	$http.get("http://localhost:8080/BooksForAll/GetBooks"+"/"+$scope.userSession.username+"/name/"+$scope.userSession.username) //TODO Add name 
			.success(function(response) {	
			   $scope.records = response;
			   $scope.result = $scope.records;//this variable will hold the search results
			});
	$scope.result2 = "";
	$scope.result3 = "";
	
	
	//Get All Likes for the specific book
	$scope.Likes = function(event){
		$scope.bookname = event.target.id;
			$http.get("http://localhost:8080/BooksForAll/GetLikes"+"/"+$scope.userSession.username+"/name/"+event.target.id)
					.success(function(response2) {	
						$scope.likes = 0 ;			
					   $scope.records2 = response2;
						for (x in $scope.records2) {							
						    $scope.likes++;
						}
					   $scope.result2 = $scope.records2;//this variable will hold the search results
					});		
	   };
	
	   //get the verified reviews for the specific book
	$scope.Reviews = function(event){
		var string = event.target.id;
		$scope.bookname2 = string.substring(0, string.length - 1);
		
		$http.get("http://localhost:8080/BooksForAll/GetVerifiedReviews"+"/"+$scope.userSession.username+"/name/"+$scope.bookname2)
		.success(function(response3) {	
		   $scope.records3 = response3;
		   $scope.result3 = $scope.records3;//this variable will hold the search results
		});
	}
	
	//get user information
	$scope.userProfile = function(usertempp){	
		
		$scope.userTemp = usertempp;
		if($scope.myVar == true)
			{
				$http.get("http://localhost:8080/BooksForAll/getUserProfileInfo"+"/"+$scope.userSession.username+"/name/"+$scope.userTemp) 
				.success(function(response7) {						
				   $scope.records7 = response7;
				   $scope.result7 = $scope.records7
					$scope.myVar = false;
					$scope.myVar2 = true;
				});
			}
		else
			{
				$scope.myVar = true;
				$scope.myVar2 = false;
			}
	}
	
	//Buy A book
	$scope.Buy = function(booknameTemp){
		document.getElementById("err").style.visibility = "hidden";
		document.getElementById("err").style.display = "none";
		document.getElementById("successBuy").style.visibility = "hidden";
		document.getElementById("successBuy").style.display = "none";
		var company = document.getElementById("company");
		var selectedcompany = company.options[company.selectedIndex].value;
		var cardnumber= document.getElementById("cardNumber").value;
		var legal = false;
		var cardowner= document.getElementById("owner").value;
		var cardyear= document.getElementById("year");
		var selectedyear = cardyear.options[cardyear.selectedIndex].value;
		var cardmonth= document.getElementById("month");
		var selectedmonth = cardmonth.options[cardmonth.selectedIndex].value;
		var legalcard= false;
		var legalowner=false;
		var legalexp=false;
		var cvv=document.getElementById("cvv").value;
		
		// Check Owner field 
		if((/\d/.test(cardowner))==true)
		{
			document.getElementById("err").innerHTML = "Illegal Owner name !";
			document.getElementById("err").style.visibility = "visible";
			document.getElementById("err").style.display = "block";
			legalowner = false;
		}
		else {
			if(cardowner == "")
				{
					document.getElementById("err").innerHTML = "Empty Owner Name!";
					legalowner = false;
					document.getElementById("err").style.visibility = "visible";
					document.getElementById("err").style.display = "block";
				}
			else
				{
					legalowner =true;
					// Check Card details  
					if(cardnumber == "")
						{
							document.getElementById("err").innerHTML = "Empty Card Number!";
							legalcard = false;
							document.getElementById("err").style.visibility = "visible";
							document.getElementById("err").style.display = "block";
						}
					else
						{
						
							if (selectedcompany == "visa" && (/^4/.test(cardnumber)) && (cardnumber.length==16) && ((/^\d+$/.test(cardnumber))))
							{
								if(cvv == "")
								{
									document.getElementById("err").innerHTML = "CVV Is Empty!";
									document.getElementById("err").style.visibility = "visible";
									document.getElementById("err").style.display = "block";
									legalcard =false;
								}
							else
								{
								console.log(/^\d+$/.test(cvv));
									if(cvv.length!=3 || (!(/^\d+$/.test(cvv))))
									{
										document.getElementById("err").innerHTML = "Illegal CVV value!";
										document.getElementById("err").style.visibility = "visible";
										document.getElementById("err").style.display = "block";
										legalcard =false;
									}
									else
									{
										legalcard =true;
									}
								}
								
							}
							else if(selectedcompany == "amex" && (/^34/.test(cardnumber)) && (cardnumber.length==15) && (/^\d+$/.test(cardnumber)))
							{
								if(cvv == "")
									{
										document.getElementById("err").innerHTML = "CVV Is Empty!";
										document.getElementById("err").style.visibility = "visible";
										document.getElementById("err").style.display = "block";
										legalcard =false;
									}
								else
									{
									console.log(/^\d+$/.test(cvv));
										if(cvv.length!=4 || (!(/^\d+$/.test(cvv))))
										{
											document.getElementById("err").innerHTML = "Illegal CVV value!";
											document.getElementById("err").style.visibility = "visible";
											document.getElementById("err").style.display = "block";
													legalcard =false;
										}
										else {
													legalcard =true;
										}
									}								
								
							}
							else {
								legalcard =false;								
								document.getElementById("err").innerHTML = "Wrong card number!";
								document.getElementById("err").style.visibility = "visible";
								document.getElementById("err").style.display = "block";
							}
							// check expiry date 
							var currentdate = new Date();
							var currentmonth = currentdate.getMonth();
							var currentyear = currentdate.getFullYear() - 2000;
							
							if(currentyear <= selectedyear && currentmonth<=selectedmonth)
							{
								legalexp = true;
							}
							else
								{
									legalexp =false;
									document.getElementById("err").innerHTML = "Illegal Expiration date";
									document.getElementById("err").style.visibility = "visible";
									document.getElementById("err").style.display = "block";
								}
							
							legal = legalexp && legalcard && legalowner;						
							if (legal == true)
							{
								document.getElementById("cardNumber").value="";
								document.getElementById("owner").value="";
								document.getElementById("cvv").value="";
								$scope.bookname3 = booknameTemp;
								
								var book = {
										bookname : $scope.bookname3,
										username : $scope.userSession.username
								}
								//buy the book for the specific
								$http.post("http://localhost:8080/BooksForAll/buyBook",book)
								.success(function() {
									var b = $scope.bookname3 +"2";
									document.getElementById(b).style.display = "none";
									document.getElementById("successBuy").style.visibility = "visible";
									document.getElementById("successBuy").style.display = "block";
									document.getElementById("buyb").disabled = true;
								});	
							}	
						}		
					}				
		}
				
	
	}
	//function to save the bookname in $scope.bookname4
	$scope.bookID = function(event){
		var string = event.target.id;
		$scope.bookname4 = string.substring(0, string.length - 1);
		document.getElementById("err").innerHTML = "";
		document.getElementById("err").style.visibility = "hidden";
		document.getElementById("err").style.display = "none";
		document.getElementById("successBuy").style.visibility = "hidden";
		document.getElementById("successBuy").style.display = "none";
		document.getElementById("buyb").disabled = false;
}
	
	//logout
	$scope.LogOut = function(){				
		
		$http.post("http://localhost:8080/BooksForAll/SignOut")
		.success(function() {
			window.location.pathname = "/BooksForAll/";
			sessionStorage.clear();
		});	
	}
	
}]);
