
angular.module('MyBooksModule',[])
	.controller('MyBooksController', ['$scope','$http', function($scope,$http) {	
	
		$scope.bookname="";
		$scope.bookname2="";
		$scope.bookname3="";
		$scope.likes = 0 ;
		$scope.myVar = true;
		$scope.myVar2 = false;					
		$scope.tempScrollTop = 0;
		$scope.ReadingRightNow = "";
		$scope.url=""
		
	$scope.userSession = JSON.parse(sessionStorage.getItem('user'));  
		
	//get all user books that bought
	$http.get("http://localhost:8080/BooksForAll/GetUserBooks"+"/"+$scope.userSession.username+"/name/"+$scope.userSession.username) 
			.success(function(response) {	
			   $scope.records = response;
			   $scope.result = $scope.records;
			});
	
	
	$scope.result2 = "";
	$scope.result3 = "";
	
	//get all likes 
	$scope.Likes = function(event){
      
		$scope.bookname = event.target.id;
			$http.get("http://localhost:8080/BooksForAll/GetLikes"+"/"+$scope.userSession.username+"/name/"+event.target.id)
					.success(function(response2) {	
						$scope.likes = 0 ;			
					   $scope.records2 = response2;
						for (x in $scope.records2) {							
						    $scope.likes++;
						}
					   $scope.result2 = $scope.records2;//this variable will hold the search results
					});
			var userInfo = {
					username:$scope.userSession.username,
					bookname:event.target.id,
					nickname:$scope.userSession.nickname
			}
			
			//check if user liked the book or not and change the button accord to if he likes or not
			$http.post("http://localhost:8080/BooksForAll/checkUserLikeBook",userInfo)
			.success(function(data) {				
				var btn = document.getElementById("LikeButton");
				btn.textContent = data.Like;
			});
		
	   };
	
	   //get all reviews of the book
	$scope.Reviews = function(event){
		 document.getElementById("rev").value = ""
		var string = event.target.id;
		$scope.bookname2 = string.substring(0, string.length - 1);		
		
		$http.get("http://localhost:8080/BooksForAll/GetVerifiedReviews"+"/"+$scope.userSession.username+"/name/"+$scope.bookname2)
		.success(function(response3) {	
		   $scope.records3 = response3;
		   $scope.result3 = $scope.records3;//this variable will hold the search results
		});
	}
	
	//get save scroll location of the book
	$scope.Read = function(event){
		var string = event.target.id;
		$scope.bookname3 = string.substring(0, string.length - 1);		
		if($scope.myVar == true)
		{				
				$http.get("http://localhost:8080/BooksForAll/getPageLine"+"/"+$scope.userSession.username+"/name1/"+$scope.bookname3+"/name2/"+$scope.userSession.username)
				.success(function(response3) {					
					if(response3.readLine > 0)
						{												
							$scope.tempScrollTop = response3.readLine;			
						}
						else
						{					
							$scope.tempScrollTop = 0;
						}
					$scope.ReadingRightNow = $scope.bookname3;
					$scope.url = response3.url;					
					$scope.myVar = false;
					$scope.myVar2 = true;
					$(window).scrollTop(0);
				});						
		}
		else
		{
			$scope.myVar = true;
			$scope.myVar2 = false;
		}
		
	}
	
	//Close the book and and save the scroll location in the database
	$scope.Back = function(){
		
		if($scope.myVar == true)
		{				
				$scope.myVar = false;
				$scope.myVar2 = true;			
				
		}
		else
		{
			//get scroll location
			$scope.tempScrollTop = $(window).scrollTop();	
			var SavePage = {
					username : $scope.userSession.username,
					bookname : $scope.bookname3,
					readLine : $scope.tempScrollTop 
			}	
				//save it in database
			$http.post("http://localhost:8080/BooksForAll/SavePageLine",SavePage)
			.success(function(response3) {				
				$scope.myVar = true;
				$scope.myVar2 = false;
				$scope.ReadingRightNow = "";
				$(window).scrollTop(0);				
			});			
		}
	}
	
	//load the saved location
	$scope.ContineuReading = function(){
		if($scope.tempScrollTop > 0 ) $(window).scrollTop($scope.tempScrollTop);
	}
	
	
	//send review to the server
	$scope.SendReview = function(tempBook){		
		var reviewS = document.getElementById("rev").value;
		var reviewS = {
				username : $scope.userSession.username,
				bookname : tempBook,
				review : reviewS
		}
		$http.post("http://localhost:8080/BooksForAll/writeReview",reviewS)
		.success(function(response5) {
			if(response5.result == "Success")
			{
				Console.log("Working...")
			}	
		});
		 document.getElementById("rev").value = ""
	}
	
	//Like or Unlike The Book
	$scope.LikeOrUnlike = function(tempBook){				
		var LikeBook = {
				username : $scope.userSession.username,
				bookname : tempBook,
				nickname: $scope.userSession.nickname
		}
		//send request to the server to Like or Unlike The Book
		$http.post("http://localhost:8080/BooksForAll/LikeBook",LikeBook)
		.success(function(response5) {
			
			//Update the Users Who Liked The Book
			$http.get("http://localhost:8080/BooksForAll/GetLikes"+"/"+$scope.userSession.username+"/name/"+tempBook)
			.success(function(response2) {	
				$scope.likes = 0 ;			
			   $scope.records2 = response2;
				for (x in $scope.records2) {							
				    $scope.likes++;
				}
			   $scope.result2 = $scope.records2;//this variable will hold the search results
			   var btn = document.getElementById("LikeButton");
			   
			   //if like and you clicked change to unlike if unlike and u clicked change the button to like
				if(btn.textContent == "Like")
					{
						btn.textContent = "UnLike";					
					}
					else
					{
						btn.textContent = "Like";		
					}
			});
			
		});
	}
	
	
	//logout user
$scope.LogOut = function(){				
		
		$http.post("http://localhost:8080/BooksForAll/SignOut")
		.success(function() {
			window.location.pathname = "/BooksForAll/";
			sessionStorage.clear();
		});	
	}
}]);
