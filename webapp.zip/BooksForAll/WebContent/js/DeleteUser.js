

angular.module('DeleteUserModule',[])
	.controller('DeleteUserController', ['$scope','$http', function($scope,$http) {
		$scope.user ="";
    $scope.query = "";//this variable will hold the user's query
    
    //get user session
	$scope.userSession = JSON.parse(sessionStorage.getItem('user'));
	
	
	//get all users
	$http.get("http://localhost:8080/BooksForAll/searchUser"+"/"+$scope.userSession.username+"/name/") 
			.success(function(response) {
			   $scope.records = response;
			   $scope.result = $scope.records;//this variable will hold the search results
			});
			
	//this method will be called upon change in the text typed by the user in the searchbox
	$scope.search = function(){
	    if (!$scope.query || $scope.query.length == 0){
	    	//get all users if there no name in the searching box
	    	$http.get("http://localhost:8080/BooksForAll/searchUser"+"/"+$scope.userSession.username+"/name/")
			.success(function(response) {				
			   $scope.records = response;
			   $scope.result = $scope.records;//this variable will hold the search results
			});
			$scope.result = $scope.records;
		}else{
		    var qstr = $scope.query.toLowerCase();
		    //get the name in the searching box
			$http.get("http://localhost:8080/BooksForAll/searchUser"+"/"+$scope.userSession.username+"/name/"+qstr)
					.success(function(response) {				
					   $scope.records = response;
					   $scope.result = $scope.records;//this variable will hold the search results
					});
				
	   }
	};
	
	//function that save the username when shown delete message
	$scope.showDeleteMessage = function(event){
		$scope.user = event.target.id;
	}
	
	
	//Delete the username
	$scope.delete = function(username2){
		 var qstr = $scope.query.toLowerCase();		
			var user = {
					username :  username2
			};
		$http.post("http://localhost:8080/BooksForAll/deleteUser",user)
		.success(function(response) {				
			  if(response.result == "success")
			  {	
				  //if success deleted update the users in the page
					$http.get("http://localhost:8080/BooksForAll/searchUser"+"/"+ $scope.userSession.username+"/name/"+qstr) ///name/Alfreds Futterkiste
					.success(function(response) {				
					   $scope.records = response;
					   $scope.result = $scope.records;//this variable will hold the search results
					});
			  }			 
		});
	}
	
	//logout User
$scope.LogOut = function(){				
		
		$http.post("http://localhost:8080/BooksForAll/SignOut")
		.success(function() {
			window.location.pathname = "/BooksForAll/";
			sessionStorage.clear();
		});	
	}
	
}]);

