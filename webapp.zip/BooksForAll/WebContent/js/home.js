

var myApp = angular.module('HomeModule',[]);

myApp.controller('Register',['$scope','$http',function($scope, $http){
	

	document.getElementById("failedRegister").style.visibility = "hidden";
	document.getElementById("failedRegister").style.display = "none";
	document.getElementById("successRegister").style.display = "none";
	document.getElementById("successRegister").style.visibility = "hidden";
	document.getElementById("failedLogIn").style.display = "none";
	document.getElementById("failedLogIn").style.visibility = "hidden";

	$scope.RegisterUser = function(){

    	document.getElementById("failedRegister").style.visibility = "hidden";
    	document.getElementById("failedRegister").style.display = "none";
    	document.getElementById("successRegister").style.display = "none";
		document.getElementById("successRegister").style.visibility = "hidden";
    	document.getElementById("failedLogIn").style.display = "none";
		document.getElementById("failedLogIn").style.visibility = "hidden";
	//This Function check if the str is a valid mail ( includes @ and . after the @)
	var isValidMail = function (str){
		if(!(str.includes("@"))){
			return false ; 
		}
		else {
			temp=str.split("@");

			if(temp[1].includes("@"))
			{
				return false ;
			}
			else {
				if(temp[1].includes("."))
				{
					return true ; 
				}
				else {
					return false ; 
				}
			}
		}
	};


		$scope.legal = true ; 	
						
		document.getElementById("signupusername").required = true;
		document.getElementById("addr").required = true;
		document.getElementById("telephon").required = true;
		document.getElementById("mil").required = true;
		document.getElementById("pass").required = true;
		document.getElementById("nick").required = true;
		document.getElementById("loginuser").required = false;
		document.getElementById("loginpwd").required = false;
		document.getElementById("image").required = false;
		document.getElementById("Des").required = false;

/** Check UserName **/

		var name = document.getElementById("signupusername");
		var namelength = name.value.length;

	if(namelength > 10 )
	{
		document.getElementById("signupusername").placeholder = "must be Up to 10 charachters";
		document.getElementById("signupusername").style.borderColor = "red"; 
		$scope.legal = false ; 
	}
	else if ((namelength <= 10 )&& (namelength >0 )) {
		document.getElementById("signupusername").style.borderColor = "green"; 
	}
	else
		{
			document.getElementById("signupusername").placeholder = "The Field Is Empty";
			document.getElementById("signupusername").style.borderColor = "red"; 
			$scope.legal = false ; 
		}

/** Check Address **/
	
	var addre = document.getElementById("addr").value;
	addres = addre.split(",");

	 if ( (addres.length ==4 ))
	{
		document.getElementById("addr").style.borderColor = "green"; 
	}
	 else if ((addres.length != 4) && (addre.length >= 0))
	{
		document.getElementById("addr").placeholder = "must be in this format St , St no , City , Postal Code";
		document.getElementById("addr").style.borderColor = "red"; 
		$scope.legal = false; 
	}
	
/** Check Telephone **/
		
	var tele = document.getElementById("telephon").value;
	var isnum = /^\d+$/.test(tele);

	if(!isnum)
	{
		document.getElementById("telephon").placeholder = "must contains only numbers";
		document.getElementById("telephon").style.borderColor = "red"; 
		$scope.legal = false ; 
	}
	else  {
		if((tele.length !=9) && (tele.length !=10))
		{
		document.getElementById("telephon").placeholder = "non-valid mobile, landline number";
		document.getElementById("telephon").style.borderColor = "red"; 
		$scope.legal = false ; 

		}
		else {
			document.getElementById("telephon").style.borderColor = "green"; 
		}

	}
	
/** Check Mail **/

	
	if(isValidMail(document.getElementById("mil").value) == true ){
		document.getElementById("mil").style.borderColor = "green"; 
	}
	else {
		document.getElementById("mil").placeholder = "non-valid email address";
		document.getElementById("mil").style.borderColor = "red"; 
		$scope.legal = false ; 
	}
	
/** Check Password **/

	if(document.getElementById("pass").value.length>8 )
	{
		document.getElementById("pass").style.borderColor = "red"; 
		$scope.legal = false ; 

	}
	else if (document.getElementById("pass").value.length==0){
		document.getElementById("pass").style.borderColor = "red"; 
		$scope.legal = false ; 
	}
	else {
		document.getElementById("pass").style.borderColor = "green"; 
	}

/** Check Nickname **/

	if(document.getElementById("nick").value.length>20)
	{
		document.getElementById("nick").style.borderColor = "red";
		document.getElementById("nick").placeholder = "Must be up to 20 charachters";
		$scope.legal = false ; 
	}
	else if (document.getElementById("nick").value.length==0)
	{
		document.getElementById("nick").style.borderColor = "red";
		document.getElementById("nick").placeholder = "This Field is Mandatory !";
		$scope.legal = false ; 
	}
	else {
		document.getElementById("nick").style.borderColor = "green";
	}

/** Check Description **/

	if((document.getElementById("Des").value.length>50))
	{
		document.getElementById("Des").style.borderColor = "red";
		document.getElementById("Des").placeholder = "Must be up to 50 charachters";
		$scope.legal = false ; 
	}
	else {
		document.getElementById("Des").style.borderColor = "green";
	}

/** Check Photo **/
	
	var img2;
	if(document.getElementById("image").value== '' )
	{
		document.getElementById("image").style.borderColor = "green ";
		img2 = "User Photos/no-img.png";		
	}
	else
	{
		document.getElementById("image").style.borderColor = "green ";
		img2 = document.getElementById("image").value;
	}
	


	//if all the requirement fulfilled then Send Request to register to the server 
	if ( $scope.legal == true )
	{			
		var user = {
		        username : document.getElementById("signupusername").value,
		        email : document.getElementById("mil").value,
		        address : document.getElementById("addr").value,
		        telephone : document.getElementById("telephon").value,
		        password : document.getElementById("pass").value,
		        nickname : document.getElementById("nick").value,
		        description : document.getElementById("Des").value,
		        photo : img2
		    };
		$scope.user = user;
		 document.getElementById("image").value='';
		 
		 
		$.ajax({
			url: "http://localhost:8080/BooksForAll/RegisterUser",
			type: 'POST',
			dataType: 'json',
			data: JSON.stringify($scope.user),
			contentType: 'application/json',			
			
			success: function (data) {				
					 if(data.Success == "yes")
						 {		
						 //if register success then show the appropriate message
						 	 document.getElementById("failedRegister").style.visibility = "hidden";
					 		 document.getElementById("successRegister").style.visibility = "visible";
					 		 document.getElementById("successRegister").style.display = "block";
						 	 document.getElementById("signupusername").value = "";
							 document.getElementById("mil").value = "";
							 document.getElementById("addr").value = "";
							 document.getElementById("telephon").value = ""
							 document.getElementById("pass").value = "";
							 document.getElementById("nick").value = "";
							 document.getElementById("Des").value = "";
							 document.getElementById("image").value = "";
						 }
					 else
						 {
						 	// if failed then show the appropriate message
						  	if(data.Success == "Username or Email Already Exists!") $scope.reason="Exist Username or Email";
						  	if(data.Success == "Error In DataBase") $scope.reason="There Is Error In The Server";
						  	document.getElementById("image").value = "";
						  	document.getElementById("failedRegister").innerHTML = "<strong>Failed!</strong> "+ $scope.reason;
				        	document.getElementById("failedRegister").style.visibility = "visible";
				        	document.getElementById("failedRegister").style.display = "block";
							document.getElementById("successRegister").style.visibility = "hidden";
						 }						 			     
			},
	        error:function(data,status,er) {	        
	        	document.getElementById("failedRegister").innerHTML = "<strong>Failed!</strong> "+ "Error" + er;
	        	document.getElementById("failedRegister").style.visibility = "visible";
	        	document.getElementById("failedRegister").style.display = "block";
				document.getElementById("successRegister").style.visibility = "hidden";
	        }
		});
	}
	};
}]);



//Controlller for Sign in
myApp.controller('SignIn',['$scope','$http',function($scope, $http){
 	
	document.getElementById("failedRegister").style.visibility = "hidden";
	document.getElementById("failedRegister").style.display = "none";
	document.getElementById("successRegister").style.display = "none";
	document.getElementById("successRegister").style.visibility = "hidden";
	document.getElementById("failedLogIn").style.display = "none";
	document.getElementById("failedLogIn").style.visibility = "hidden";
	
	//Send Log in Request to the server
	$scope.LogIn = function() {
    	document.getElementById("failedRegister").style.visibility = "hidden";
    	document.getElementById("failedRegister").style.display = "none";
    	document.getElementById("successRegister").style.display = "none";
		document.getElementById("successRegister").style.visibility = "hidden";
    	document.getElementById("failedLogIn").style.display = "none";
		document.getElementById("failedLogIn").style.visibility = "hidden";
		
		var user = {
		        username : document.getElementById('loginuser').value,	    
		        password : document.getElementById('loginpwd').value	       
			    };

		$.ajax({
			url: "http://localhost:8080/BooksForAll/SignIn",
			type: 'POST',
			dataType: 'json',
			data: JSON.stringify(user),
			contentType: 'application/json',			
			
			success: function (data) {
				 if(data.result == "Found")
			        {
					 //if the user is found then get the infromation from the session user and save it in the session of browse
					 $.ajax({
							url: "http://localhost:8080/BooksForAll/SessionUser",
							type: 'POST',
							dataType: 'json',
							data: JSON.stringify(user),
							contentType: 'application/json',			
							
							success: function (data2) {														
								if(data2 != null)
								{					
									sessionStorage.setItem('user',JSON.stringify(data2));
									window.location.pathname = "/BooksForAll/BrowseBooksAndProfile.html"; 						
								}
								else
								{
									document.getElementById("failedLogIn").innerHTML = "<strong>Failed!</strong> "+ "Error In Session";
						        	document.getElementById("failedLogIn").style.visibility = "visible";
						        	document.getElementById("failedLogIn").style.display="block";							
								}
							}
							,error:function(data,status,er) {						;
								document.getElementById("failedLogIn").innerHTML = "<strong>Failed!</strong> "+"Error" + er;
					        	document.getElementById("failedLogIn").style.visibility = "visible";
					        	document.getElementById("failedLogIn").style.display="block";
					        }
						});
			        }
			        else
			        {
			        	document.getElementById("failedLogIn").innerHTML = "<strong>Failed!</strong> "+ "Wrong User Name or Password";
			        	document.getElementById("failedLogIn").style.visibility = "visible";
			        	document.getElementById("failedLogIn").style.display="block";
			        }
			},
	        error:function(data,status,er) {
	        	document.getElementById("failedLogIn").innerHTML = "<strong>Failed!</strong> "+"Error" + er;
	        	document.getElementById("failedLogIn").style.visibility = "visible";
	        	document.getElementById("failedLogIn").style.display="block";				
	        }
		});			
	};
}]);