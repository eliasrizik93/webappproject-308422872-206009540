
angular.module('AdminApproveReviewsModule',[])
	.controller('AdminApproveReviewsController', ['$scope','$http', function($scope,$http) {
	
    $scope.query = "";//this variable will hold the user's query
    $scope.userSession = JSON.parse(sessionStorage.getItem('user'));
    
    //get all Unverified Reviews from the server
	$http.get("http://localhost:8080/BooksForAll/getUnverifiedReviews"+"/"+$scope.userSession.username+"/name/") 
			.success(function(response) {	
			   $scope.records = response;
			   $scope.result = $scope.records;//this variable will hold the search results
			});		
	
	//function for approving review
	$scope.Approve = function(event){
		
		// review id
		var reviewID = {
				ID :  event.target.id
		};
		$http.post("http://localhost:8080/BooksForAll/verifiyReview",reviewID)
		.success(function(response) {				
			  if(response.result == "Success")
			  {
				  //Update the List of Unverified Reviews
				  $http.get("http://localhost:8080/BooksForAll/getUnverifiedReviews"+"/"+$scope.userSession.username+"/name/") 
					.success(function(response) {				
					   $scope.records = response;
					   $scope.result = $scope.records;//this variable will hold the search results
					});
			  }
			  else
			  {
			  	
			  }
		});
	}
	
	//User Log Out
$scope.LogOut = function(){				
		
		$http.post("http://localhost:8080/BooksForAll/SignOut")
		.success(function() {
			window.location.pathname = "/BooksForAll/";
			sessionStorage.clear();
		});	
	}
	
}]);

