
angular.module('purchasesHistoryModule',[])
	.controller('purchasesHistoryController', ['$scope','$http', function($scope,$http) {
	
    $scope.query = "";//this variable will hold the user's query
    $scope.userSession = JSON.parse(sessionStorage.getItem('user'));
    
    //get all purchases history from the server
	$http.get("http://localhost:8080/BooksForAll/getPurchasesHistory"+"/"+$scope.userSession.username+"/name/") 
			.success(function(response) {				
			   $scope.records = response;
			   $scope.result = $scope.records;//this variable will hold the search results
			});
			
	//log out from user
$scope.LogOut = function(){				
		
		$http.post("http://localhost:8080/BooksForAll/SignOut")
		.success(function() {
			window.location.pathname = "/BooksForAll/";
			sessionStorage.clear();
		});	
	}
	
}]);

