package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Constants.AppConstants;
import model.Book;
import model.UserBook;

/**
 * Servlet implementation class GetBooks
 */
@WebServlet("/GetBooks/*")
public class GetBooks extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetBooks() {
        super();
        // TODO Auto-generated constructor stub
    }


    /**
     * Get All Books That User Did not Buy
     * @return json format of list that contain all the book info
     * @throws ServletException, IOException
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		String uri = request.getRequestURI();
		String var = uri.substring(uri.indexOf(AppConstants.NAME) + AppConstants.NAME.length() + 1);
		var = var.replaceAll("\\%20", " ");		
		Gson gson = new GsonBuilder().create();
		String JsonResult;
		int Check2;
		try 
		{
			Context context = new InitialContext();
    		BasicDataSource ds = (BasicDataSource)context.lookup(
    				getServletContext().getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
			Connection conn = ds.getConnection();
			PreparedStatement stmt1,stmt2;		
    		 
    		 ArrayList<Book> BooksList = new ArrayList<Book>();
 	    	 ArrayList<UserBook> userBookList= new ArrayList<UserBook>();
 	    	 
 	    	//Get All Books That User Bought
			stmt1=conn.prepareStatement(AppConstants.SELECT_USERNAME_BUY_BOOK);	
			stmt1.setString(1,var);				
			ResultSet Result2 = stmt1.executeQuery();
			while(Result2.next()) userBookList.add(new UserBook(Result2.getString(1),Result2.getString(2)));
			
			//Get All Books That User Did not Buy
			stmt2=conn.prepareStatement(AppConstants.SELECT_BOOK);						
			ResultSet Result = stmt2.executeQuery();								    		    		
			
			//Insert Into BookList only The Books That User Didnot Buy
    		while (Result.next())
    		{	    			    
    			Check2 = 0;	 					
	    		for(int i = 0 ; i < userBookList.size();i++)
	    			if(userBookList.get(i).getBook().equals(Result.getString(1))) Check2 = 1;		    			
	    		if(Check2 == 0) BooksList.add(new Book(Result.getString(1),Result.getString(2),Result.getDouble(3),Result.getString(4),Result.getInt(5),Result.getString(6)));    
    		}	    	
    		JsonResult = gson.toJson(BooksList);
			PrintWriter writer = response.getWriter();
			writer.print(JsonResult);
    		Result2.close();							
			Result.close();
			stmt1.close();			
			conn.close();

			}catch (SQLException | NamingException e) {
				JsonResult = gson.toJson("null");
				PrintWriter writer = response.getWriter();
				writer.print(JsonResult);
			getServletContext().log("Error while closing connection", e);
			response.sendError(500);//internal server error
			}	
		out.close();	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
