package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Constants.AppConstants;
import model.Review;

/**
 * Servlet implementation class verifiyReview
 */
@WebServlet("/verifiyReview")
public class verifiyReview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public verifiyReview() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	
	
	/**
	 * Change Verify Value From 0 To 1, This Servlet To Verify The UnVerified Reviews
	 * @return json format if Success or Not Success
	 * @throws ServletException, IOException
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine = null;			
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String Json = jsonFileContent.toString();		
		Gson gson = new GsonBuilder().create();
		Review reviewInfo = gson.fromJson(Json, Review.class);	
		try 
		{
			Context context = new InitialContext();
    		BasicDataSource ds = (BasicDataSource)context.lookup(
    				getServletContext().getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
    		Connection conn = ds.getConnection();
    		 PreparedStatement stmt1;		
    		  	 //Update The Verifiy Value from 0 to 1 That Mean The Review Has Been Verfied 
    			stmt1=conn.prepareStatement(AppConstants.UPDATE_REVIEW_VERIFY);	
				stmt1.setInt(1, reviewInfo.getID());
				stmt1.executeUpdate();
				stmt1.close();			
				conn.close();
				out.println("{ \"result\": \"Success\"}");		
			}catch (SQLException | NamingException e) {	
				out.println("{ \"result\": \"Not Success\"}");
			getServletContext().log("Error while closing connection", e);
			response.sendError(500);//internal server error
			}	
		out.close();	
	}

}
