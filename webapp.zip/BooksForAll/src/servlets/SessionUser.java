package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import model.User;

/**
 * Servlet implementation class SessionUser
 */
@WebServlet("/SessionUser")
public class SessionUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionUser() {
        super();
        // TODO Auto-generated constructor stub
    }


    
    /**
     * Get User Session Info
     * @return json format the user information
     * @throws ServletException, IOException
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{			
			HttpSession session= request.getSession(true);	
			//Get The User Info From The Session And Return It To The Client
			User temp = (User) session.getAttribute("User");
			response.setContentType("application/json; charset=UTF-8");
			PrintWriter writer = response.getWriter();
			Gson gson = new Gson();
			if(temp != null)
			{
				String UserJsonResult = gson.toJson(temp);
				writer.print(UserJsonResult);
			}
			else
			{	
				String UserJsonResult = gson.toJson("null");
				writer.print(UserJsonResult);
			}
			}catch (IOException e) {  
				getServletContext().log("Error while Taking User From Session", e);
	    		response.sendError(500);//internal server error
	        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
