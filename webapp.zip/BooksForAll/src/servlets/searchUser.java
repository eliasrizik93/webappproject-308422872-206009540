package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Constants.AppConstants;
import model.User;

/**
 * Servlet implementation class searchUser
 */
@WebServlet("/searchUser/*")
public class searchUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public searchUser() {
        super();
        // TODO Auto-generated constructor stub
    }

    
    
    /**
     *	Return List of Users That there Username Start With Given Letters, This Servlet is For Searching for Specifc Username
     * @return json format  List of Users That there Username Start With Given Letters
     * @throws ServletException, IOException
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		Gson gson = new GsonBuilder().create();		
		ArrayList<User> UsersList = new ArrayList<User>(); 
		//Get The Search Letters
		String uri = request.getRequestURI();
		String var = uri.substring(uri.indexOf(AppConstants.NAME) + AppConstants.NAME.length() + 1);
		String JsonResult;		
			try 
			{
				Context context = new InitialContext();
	    		BasicDataSource ds = (BasicDataSource)context.lookup(
	    				getServletContext().getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
	    		Connection conn = ds.getConnection();
	    		PreparedStatement stmt1,stmt2;			    		 
	    		 
	    		//if var is Empty That Mean The Search is Empty And Return All Users
	    		 if(var.length() == 0)
	    		 {
	    			 //Select All Users Except for Admin
	     			stmt2=conn.prepareStatement(AppConstants.SELECT_USERS);					
	 				ResultSet Result = stmt2.executeQuery();
	 				while(Result.next()) UsersList.add(new User(Result.getString(1),Result.getString(2),Result.getString(3),Result.getString(4),Result.getString(5),Result.getString(6),Result.getString(7),Result.getString(8)));		
	 	    		JsonResult = gson.toJson(UsersList);
	 				PrintWriter writer = response.getWriter();
	 				writer.print(JsonResult);
	 				Result.close();							
	 				Result.close();
	 				stmt2.close();			
	 				conn.close();
	    		 }
	    		 else
	    		 {
	    			 //Get All Users That there username Start with var
    	 			stmt1=conn.prepareStatement(AppConstants.SELECT_USERS_SEARCH);	
        			stmt1.setString(1,var + "%");				
    				ResultSet Result = stmt1.executeQuery();
    				while(Result.next()) UsersList.add(new User(Result.getString(1),Result.getString(2),Result.getString(3),Result.getString(4),Result.getString(5),Result.getString(6),Result.getString(7),Result.getString(8)));		
    	    		JsonResult = gson.toJson(UsersList);
    				PrintWriter writer = response.getWriter();
    				writer.print(JsonResult);
    				Result.close();							
    				Result.close();
    				stmt1.close();			
    				conn.close();
	    		 }    		
				}catch (SQLException | NamingException e) {
					JsonResult = gson.toJson("null");
					PrintWriter writer = response.getWriter();
					writer.print(JsonResult);
				getServletContext().log("Error while closing connection", e);
				response.sendError(500);//internal server error
				}	
			out.close();				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
