package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Constants.AppConstants;
import model.SaveUserPage;

/**
 * Servlet implementation class getPageLine
 */
@WebServlet("/getPageLine/*")
public class getPageLine extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getPageLine() {
        super();
        // TODO Auto-generated constructor stub
    }

	
    /**
     * Get The Location of The Saved Scroll
     * @return json format of class SaveUserPage that have Saved Location of the user and book
     * @throws ServletException, IOException
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		Gson gson = new GsonBuilder().create();
		
		//Get URL
		String uri = request.getRequestURI();
		
		//Get The Username After name1
		String var = uri.substring(uri.indexOf(AppConstants.NAME1) + AppConstants.NAME1.length() + 1);
		var = var.substring(0,var.indexOf(AppConstants.NAME2)-1);
		var = var.replaceAll("\\%20", " ");
		
		//Get The Bookname After name2
		String var2 = uri.substring(uri.indexOf(AppConstants.NAME2) + AppConstants.NAME2.length() + 1);
		var2 = var2.replaceAll("\\%20", " ");
		String JsonResult;	
		
		//Create Empty Class of SaveUserPage
		SaveUserPage userPage = new SaveUserPage();
		try 
		{
			Context context = new InitialContext();
    		BasicDataSource ds = (BasicDataSource)context.lookup(
    				getServletContext().getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
    		Connection conn = ds.getConnection();
    		
    		//Join ReadTable And book Table To Get The Url From The Book Table And Select in ReadTable The Specific Username
    		//and Bookname
    		PreparedStatement stmt1;		    		     	 	      		
			stmt1=conn.prepareStatement(AppConstants.SELECT_USER_BOOKS_JOIN_PAGE_LINE);
			stmt1.setString(1, var2);
			stmt1.setString(2,var);
			ResultSet Result = stmt1.executeQuery();
			while(Result.next()) 
				{
					userPage.setUsername(Result.getString(1));
					userPage.setBookname(Result.getString(2));
					userPage.setReadLine(Result.getDouble(3));	
					userPage.setUrl(Result.getString(9));
				}
			
    		JsonResult = gson.toJson(userPage);
			PrintWriter writer = response.getWriter();
			writer.print(JsonResult);
						
			Result.close();
			stmt1.close();			
			conn.close();
			}catch (SQLException | NamingException e) {
				JsonResult = gson.toJson("null");
				PrintWriter writer = response.getWriter();
				writer.print(JsonResult);
			getServletContext().log("Error while closing connection", e);
			response.sendError(500);//internal server error
			}	
		out.close();	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
