package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Constants.AppConstants;
import model.User;

/**
 * Servlet implementation class getUserProfileInfo
 */
@WebServlet("/getUserProfileInfo/*")
public class getUserProfileInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getUserProfileInfo() {
        super();
        // TODO Auto-generated constructor stub
    }


    /**
     * Servlet To Get All Specific User Information
     * @return json format of list that contain user information
     * @throws ServletException, IOException
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response) 
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		Gson gson = new GsonBuilder().create();		
		 ArrayList<User> UsersList = new ArrayList<User>(); 	
		 //get URL
		String uri = request.getRequestURI();
		//Get The Variable After "name="
		String var = uri.substring(uri.indexOf(AppConstants.NAME) + AppConstants.NAME.length() + 1);
		String JsonResult;		
			try 
			{
				Context context = new InitialContext();
	    		BasicDataSource ds = (BasicDataSource)context.lookup(
	    				getServletContext().getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
	    		Connection conn = ds.getConnection();
	    		
	    		//Get User Information
	    		PreparedStatement stmt1;			    		 	    		 
	 			stmt1=conn.prepareStatement(AppConstants.SELECT_USERS_PROFILE);	
    			stmt1.setString(1,var);				
				ResultSet Result = stmt1.executeQuery();
				while(Result.next()) UsersList.add(new User(Result.getString(1),Result.getString(2),Result.getString(3),Result.getString(4),Result.getString(5),Result.getString(6),Result.getString(7),Result.getString(8)));		
	    		JsonResult = gson.toJson(UsersList);
				PrintWriter writer = response.getWriter();
				writer.print(JsonResult);
				Result.close();							
				stmt1.close();			
				conn.close();	    		 		
				}catch (SQLException | NamingException e) {
					JsonResult = gson.toJson("null");
					PrintWriter writer = response.getWriter();
					writer.print(JsonResult);
				getServletContext().log("Error while closing connection", e);
				response.sendError(500);//internal server error
				}	
			out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
