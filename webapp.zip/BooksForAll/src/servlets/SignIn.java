package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Constants.AppConstants;
import model.User;

/**
 * Servlet implementation class SignIn
 */
@WebServlet("/SignIn")
public class SignIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignIn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	
	/**
	 * Check If User Exist if Username And Passsword Are Correct then Save User In Session And Return Found
	 * @return json format if User Found or Not Found
	 * @throws ServletException, IOException
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session= request.getSession(true);
		response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine = null;			
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String JsonS = jsonFileContent.toString();		
		Gson gson = new GsonBuilder().create();
		User tempUser = gson.fromJson(JsonS, User.class);
		boolean check=false;	
		try 
		{
			Context context = new InitialContext();
    		BasicDataSource ds = (BasicDataSource)context.lookup(
    				getServletContext().getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
    		Connection conn = ds.getConnection();
    		 PreparedStatement stmt2;		    
    		 
    		 //Check If Username And Password Correct 
			stmt2=conn.prepareStatement(AppConstants.SELECT_USERNAME_AND_PASSWORD);	
			stmt2.setString(1,tempUser.getUsername());
			stmt2.setString(2,tempUser.getPassword());
			ResultSet Result = stmt2.executeQuery();
			
			if(Result.next())
			{
				//If User And Password Found Save it in Session and Change check Value To 1 That Mean User Found
				User temp1 = new User(Result.getString(1),Result.getString(2), Result.getString(3), Result.getString(4), Result.getString(5),Result.getString(6), Result.getString(7),Result.getString(8));			
				check = true;  		
				session=request.getSession();
				session.setAttribute("User", temp1);	
			}				
			Result.close();
			stmt2.close();			
			conn.close();
			}catch (SQLException | NamingException e) {
			getServletContext().log("Error while closing connection", e);
			response.sendError(500);//internal server error
			}
		if(check)
		{	
			out.println("{ \"result\": \"Found\"}");
		}
		else
		{				
			out.println("{ \"result\": \"Wrong User Name or Password\"}");			
		}
		out.close();	
	}

}
