package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Constants.AppConstants;
import model.User;

/**
 * Servlet implementation class RegisterUser
 */
@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}


	/**
	 * Servlet For Register User Check if Email And Username Already Exists , if They Exist Then Dont Register The User
	 * if not Exist Then Register The User
	 * @return json format if the Register Successed or Not
	 * @throws ServletException, IOException
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session= request.getSession(true);
		response.setContentType("application/json; charset=UTF-8"); 
		PrintWriter out = response.getWriter();
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
		StringBuilder jsonFileContent = new StringBuilder();
		String nextLine = null;			
		while((nextLine = br.readLine()) != null) jsonFileContent.append(nextLine);
		String JsonS = jsonFileContent.toString();		
		Gson gson = new GsonBuilder().create();
		User tempUser = gson.fromJson(JsonS, User.class);
		try 
		{
			Context context = new InitialContext();
    		BasicDataSource ds = (BasicDataSource)context.lookup(
    				getServletContext().getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
    		Connection conn = ds.getConnection();
    		 PreparedStatement stmt1,stmt2;		    	
			//Check if Username or Email ALready Exist
			stmt2=conn.prepareStatement(AppConstants.SELECT_USERNAME_AND_EMAIL);	
			stmt2.setString(1,tempUser.getUsername());
			stmt2.setString(2, tempUser.getEmail());
			ResultSet Result = stmt2.executeQuery();
			if(Result.next())
			{
				//Return That User or Email Already Exist
				out.println("{ \"Success\": \"Username or Email Already Exists!\"}");
				out.close();								
			}
			else{
				//Insert User Info in Users Table
				stmt1 = conn.prepareStatement(AppConstants.INSERT_USER); 
				stmt1.setString(1, tempUser.getUsername());
				stmt1.setString(2, tempUser.getEmail());
				stmt1.setString(3, tempUser.getAddress());
				stmt1.setString(4,  tempUser.getTelephone());
				stmt1.setString(5, tempUser.getPassword());	
				stmt1.setString(6, tempUser.getNickname());
				stmt1.setString(7, tempUser.getDescription());
				stmt1.setString(8, tempUser.getPhoto());
				stmt1.executeUpdate();
				
				User TempUser = new User( tempUser.getUsername(),tempUser.getEmail(), tempUser.getAddress(), tempUser.getTelephone(), tempUser.getPassword(),tempUser.getNickname(), tempUser.getDescription(),tempUser.getPhoto());							
				session.setAttribute("User", TempUser);
				
				out.println("{ \"Success\": \"yes\"}");
				out.close();
				conn.commit();
				stmt1.close();					
			}
			Result.close();
			stmt2.close();			
			conn.close();
			}catch (SQLException | NamingException e) {
				out.println("{ \"Success\": \"Error In DataBase\"}");
				out.close();								
			getServletContext().log("Error while closing connection", e);
			response.sendError(500);//internal server error
			}
	}
}
