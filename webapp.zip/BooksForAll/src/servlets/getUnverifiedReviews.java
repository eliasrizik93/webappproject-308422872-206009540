package servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Constants.AppConstants;
import model.Review;

/**
 * Servlet implementation class getUnverifiedReviews
 */
@WebServlet("/getUnverifiedReviews/*")
public class getUnverifiedReviews extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getUnverifiedReviews() {
        super();
        // TODO Auto-generated constructor stub
    }


    /**
     * Get All Reviews That Are Not Verified
     * @return json format of list that has all the Unverified Reviews
     * @throws ServletException, IOException
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		Gson gson = new GsonBuilder().create();
		String JsonResult;
		try 
		{
			Context context = new InitialContext();
    		BasicDataSource ds = (BasicDataSource)context.lookup(
    				getServletContext().getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
    		Connection conn = ds.getConnection();
    		PreparedStatement stmt1;		
    		 
    		ArrayList<Review> ReviewsList = new ArrayList<Review>(); 	     	    	
    		//Select The Unverified Reviews
			stmt1=conn.prepareStatement(AppConstants.SELECT_UNVERIFIED_REVIEW);	
			stmt1.setInt(1, 0);
			ResultSet Result = stmt1.executeQuery();
			while(Result.next()) ReviewsList.add(new Review(Result.getInt(1),Result.getString(2),Result.getString(3),Result.getString(4),Result.getInt(5)));															    			    			   	    	
    		JsonResult = gson.toJson(ReviewsList);
			PrintWriter writer = response.getWriter();
			writer.print(JsonResult);
			
			Result.close();							
			Result.close();
			stmt1.close();			
			conn.close();
			}catch (SQLException | NamingException e) {
				JsonResult = gson.toJson("null");
				PrintWriter writer = response.getWriter();
				writer.print(JsonResult);
			getServletContext().log("Error while closing connection", e);
			response.sendError(500);//internal server error
			}	
		out.close();	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
