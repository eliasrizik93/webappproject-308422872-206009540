package Constants;


import java.lang.reflect.Type;
import java.util.Collection;

import com.google.gson.reflect.TypeToken;

import model.Book;
import model.Review;
import model.User;
import model.UserBook;



/**
 * A simple place to hold global application constants
 */
public interface AppConstants {
	public final String JSON_FILES = "json_files";
	public final String USERS = "users";
	public final String USERS_FILE = USERS + ".json";
	public final String BOOKS = "books";
	public final String BOOKS_FILE = BOOKS + ".json";
	public final String REVIEWS = "reviews";
	public final String REVIEWS_FILE = REVIEWS + ".json";
	public final String LIKES = "likes";
	public final String LIKES_FILE = LIKES + ".json";
	
	public final String NAME = "name";
	public final String NAME1 = "name1";
	public final String NAME2 = "name2";
	public final String SEARCH = "search=";	
	//derby constants
	public final String DB_NAME = "DB_NAME";
	public final String DB_DATASOURCE = "DB_DATASOURCE";
	public final String DB_DATASOURCE2 = "java:comp/env/jdbc/ExampleDB";
	public final String PROTOCOL = "jdbc:derby:"; 
	public final String OPEN = "Open";
	public final String SHUTDOWN = "Shutdown";
	
	
	public final Type BOOKS_COLLECTION = new TypeToken<Collection<Book>>() {}.getType();
	public final Type USERS_COLLECTION = new TypeToken<Collection<User>>() {}.getType();
	public final Type UserBook_COLLECTION = new TypeToken<Collection<UserBook>>() {}.getType();
	public final Type REVIEWS_COLLECTION = new TypeToken<Collection<Review>>() {}.getType();
	
	
	public final String CREATE_USERS_TABLE = "CREATE TABLE USERS(username VARCHAR(30) NOT NULL,email VARCHAR(30) NOT NULL,address VARCHAR(100) NOT NULL,telephone VARCHAR(30) NOT NULL,password VARCHAR(30) NOT NULL,nickname VARCHAR(30) NOT NULL,description VARCHAR(300),photo VARCHAR(200), PRIMARY KEY(username))";
	public final String CREATE_BOOKS_TABLE = "CREATE TABLE BOOKS(bookname varchar(200),image varchar(200),price DOUBLE,description VARCHAR(300),numberoflikes INTEGER,url VARCHAR(300), PRIMARY KEY(bookname))";
	public final String CREATE_BUY_TABLE = "CREATE TABLE BUY(username varchar(30),bookname varchar(200),FOREIGN KEY (username) REFERENCES USERS(username),FOREIGN KEY (bookname) REFERENCES BOOKS(bookname))";
	public final String CREATE_LIKE_A_BOOK = "CREATE TABLE LIKEBOOK(username varchar(30) NOT NULL,nickname VARCHAR(30) NOT NULL,bookname varchar(200) NOT NULL,FOREIGN KEY (username) REFERENCES USERS(username),FOREIGN KEY (bookname) REFERENCES BOOKS(bookname))";
	public final String CREATE_REVIEW_TABLE="CREATE TABLE REVIEWS(ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),username varchar(30),bookname varchar(200),review varchar(1000),verified INTEGER,PRIMARY KEY(ID),FOREIGN KEY (username) REFERENCES USERS(username),FOREIGN KEY (bookname) REFERENCES BOOKS(bookname))";
	public final String CREATE_READ_TABLE = "CREATE TABLE READTABLE(username varchar(30) NOT NULL,bookname varchar(200) NOT NULL,readline DOUBLE,FOREIGN KEY (username) REFERENCES USERS(username),FOREIGN KEY (bookname) REFERENCES BOOKS(bookname))";
	
	//INSERT
	public final String INSERT_USER = "INSERT INTO USERS(username,email,address,telephone,password,nickname,description,photo) VALUES(?,?,?,?,?,?,?,?)";
	public final String INSERT_BOOK = "INSERT INTO BOOKS(bookname,image,price,description,numberoflikes,url) VALUES(?,?,?,?,?,?)";	
	public final String INSERT_USER_BOOK_LIKE = "INSERT INTO LIKEBOOK(username,nickname,bookname) values(?,?,?)";
	public final String INSERT_REVIEW = "INSERT INTO REVIEWS(username,bookname,review,verified) VALUES(?,?,?,?)";	
	public final String INSERT_USER_BUY_BOOK = "INSERT INTO BUY(username,bookname) VALUES(?,?)";	
	public final String INSERT_USER_READ_PAGE = "INSERT INTO READTABLE(username,bookname,readline) VALUES(?,?,?)";	
	
	
	//SELECT
	public final String SELECT_USERNAME_AND_PASSWORD = "SELECT * FROM USERS WHERE UserName=? AND Password=?";
	public final String SELECT_USERNAME_AND_EMAIL= "SELECT * FROM USERS WHERE username=? OR email=?";
	public final String SELECT_USERNAME="SELECT * FROM USERS WHERE UserName=?";
	public final String SELECT_USERNAME_BUY_BOOK = "SELECT * FROM BUY WHERE USERNAME=?";
	public final String SELECT_LIKE_BOOK="SELECT * FROM LIKEBOOK WHERE username=? AND bookname=?";
	public final String SELECT_BUY_BOOK="SELECT * FROM buy WHERE username=? AND bookname=?";
	public final String SELECT_BOOK = "SELECT * FROM BOOKS";
	public final String SELECT_USER_BOOKS = "SELECT * FROM BUY WHERE username=?";
	public final String SELECT_BUY_BOOK_JOIN_TABLE = "SELECT * FROM BOOKS INNER JOIN BUY ON books.bookname = BUY.bookname where username=?";	
	public final String SELECT_LIKEBOOK_USERS_JOIN_TABLE= "SELECT * FROM USERS INNER JOIN LIKEBOOK ON USERS.username = LIKEBOOK.username where LIKEBOOK.bookname=?";

	public final String SELECT_NICKNAME_LIKE_BOOK = "SELECT * FROM likebook where bookname=?";
	
	public final String SELECT_USER_PAGE_LINE = "SELECT * FROM readtable where username=? and bookname=?";
	public final String SELECT_USER_BOOKS_JOIN_PAGE_LINE = "SELECT * FROM readtable INNER JOIN books ON readtable.bookname = books.bookname where readtable.username=? and readtable.bookname=?";
	public final String SELECT_BOOK_REVIEWS = "SELECT * FROM REVIEWS WHERE bookname=? AND verified=?";
	public final String SELECT_UNVERIFIED_REVIEW = "SELECT * FROM REVIEWS WHERE verified=?";
	public final String SELECT_VERIFIED_REVIEW = "SELECT * FROM REVIEWS WHERE verified=? and bookname=?";
	public final String SELECT_VERIFIED_REVIEW_USER_JOIN = "SELECT * FROM reviews INNER JOIN users ON USERS.username = reviews.username where reviews.bookname=? and verified = ?";
	public final String SELECT_USERS = "SELECT * FROM USERS where username<>'admin'";
	public final String SELECT_BUY = "SELECT * FROM Buy";
	public final String SELECT_USERS_SEARCH = "SELECT * FROM USERS where username<>'admin' and  lower(username) like ?";	
	public final String SELECT_USERS_PROFILE = "SELECT * FROM USERS where username=?";

	
	//DELETE	
	public final String DELETE_USER_BOOK_LIKE = "DELETE FROM LIKEBOOK WHERE username=? AND bookname=?";
	public final String DELETE_USER = "DELETE FROM USERS WHERE username = ?";
	public final String DELETE_USER_LIKEBOOK = "DELETE FROM LIKEBOOK WHERE username=?";
	public final String DELETE_USER_BUY = "DELETE FROM BUY WHERE username=?";
	public final String DELETE_USER_REVIEWS = "DELETE FROM REVIEWS WHERE username=?";
	public final String DELETE_USER_READTABLE= "DELETE FROM READTABLE WHERE username=?";
	
	//UPDATE
	public final String UPDATE_BOOK_LIKES_PLUS = "UPDATE BOOKS SET numberoflikes=numberoflikes+1 WHERE bookname=?";
	public final String UPDATE_BOOK_LIKES_MINUS = "UPDATE BOOKS SET numberoflikes=numberoflikes-1 WHERE bookname=?";
	public final String UPDATE_REVIEW_VERIFY = "UPDATE REVIEWS SET verified=1 WHERE ID=?";
	public final String UPDATE_Read_Page = "UPDATE READTABLE SET readline=? WHERE username=? and bookname=?";
	
	
}
