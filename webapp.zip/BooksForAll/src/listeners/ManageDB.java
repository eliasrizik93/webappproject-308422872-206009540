package listeners;



import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


import Constants.AppConstants;
import model.Book;
import model.Review;
import model.User;
import model.UserLikeBook;




/**
 * An listener that reads the books,likes,reviews,users json files and populates the data into a Derby database
 */
@WebListener
public class ManageDB implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public ManageDB() {
        // TODO Auto-generated constructor stub
    }
    
    //utility that checks whether the tables already exists
    private boolean tableAlreadyExists(SQLException e) {
        boolean exists;
        if(e.getSQLState().equals("X0Y32")) {
            exists = true;
        } else {
            exists = false;
        }
        return exists;
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent event)  { 
    	ServletContext cntx = event.getServletContext();
    	
    	try{
    		
    		//obtain ExampleDB data source from Tomcat's context
    		Context context = new InitialContext();
    		BasicDataSource ds = (BasicDataSource)context.lookup(
    				cntx.getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.OPEN);
    		Connection conn = ds.getConnection();
    		
    		boolean created = false;
    		try{
    			//Create The Tables    			
    			Statement stmt = conn.createStatement();
    			 PreparedStatement stmt1;    			
    			stmt.executeUpdate(AppConstants.CREATE_USERS_TABLE);
    			stmt.executeUpdate(AppConstants.CREATE_BOOKS_TABLE);
    			stmt.executeUpdate(AppConstants.CREATE_BUY_TABLE);  
    			stmt.executeUpdate(AppConstants.CREATE_REVIEW_TABLE);
    			stmt.executeUpdate(AppConstants.CREATE_LIKE_A_BOOK);
    			stmt.executeUpdate(AppConstants.CREATE_READ_TABLE);
    			
    			//Insert The Admin User
    			stmt1 = conn.prepareStatement(AppConstants.INSERT_USER); 
					stmt1.setString(1, "admin");
					stmt1.setString(2, "email");
					stmt1.setString(3, "address");
					stmt1.setInt(4,  00);
					stmt1.setString(5, "Passw0rd");	
					stmt1.setString(6, "nickname");
					stmt1.setString(7, "description");
					stmt1.setString(8, "");
					stmt1.executeUpdate();
					
					/*
					drop table readtable;
   					drop table likebook;
					drop table reviews;
					drop table buy;
	    		 	drop table users;
					drop table books;
					
    			  */
    			//commit update
        		conn.commit();
        		stmt.close();
    		}catch (SQLException e){
    			//check if exception thrown since table was already created (so we created the database already 
    			//in the past
    			created = tableAlreadyExists(e);
    			if (!created){
    				throw e;//re-throw the exception so it will be caught in the
    				//external try..catch and recorded as error in the log
    			}
    		}
    		if (!created){    	
    			//populate users table with users data from json file 	
    			Collection<User> users = loadUsers(cntx.getResourceAsStream(File.separator + AppConstants.JSON_FILES+File.separator + AppConstants.USERS_FILE));
    			PreparedStatement pstmt = conn.prepareStatement(AppConstants.INSERT_USER);
    			for (User user : users){
    				pstmt.setString(1, user.getUsername());
    				pstmt.setString(2, user.getEmail());
    				pstmt.setString(3, user.getAddress());
    				pstmt.setString(4, user.getTelephone());
    				pstmt.setString(5, user.getPassword());
    				pstmt.setString(6, user.getNickname());
    				pstmt.setString(7, user.getDescription());
    				pstmt.setString(8, user.getPhoto());
    				pstmt.executeUpdate();
    			}
    			//populate Book table with users data from json file 
    			Collection<Book> books = loadBooks(cntx.getResourceAsStream(File.separator+	AppConstants.JSON_FILES+File.separator +AppConstants.BOOKS_FILE));
    			PreparedStatement pstmt2 = conn.prepareStatement(AppConstants.INSERT_BOOK);
    			for (Book book : books){
    				pstmt2.setString(1, book.getBookname());
    				pstmt2.setString(2, book.getImage());
    				pstmt2.setDouble(3, book.getPrice());
    				pstmt2.setString(4, book.getDescription());    			    				    		
    				pstmt2.setInt(5, book.getLikes()); 
    				pstmt2.setString(6, book.getUrl());
    				pstmt2.executeUpdate();
    			}
    			//populate Review table with users data from json file 
    			Collection<Review> reviews = loadReviews(cntx.getResourceAsStream(File.separator +	AppConstants.JSON_FILES+File.separator + AppConstants.REVIEWS_FILE));
    			PreparedStatement pstmt3 = conn.prepareStatement(AppConstants.INSERT_REVIEW);
    			for (Review review : reviews){
    				pstmt3.setString(1, review.getUsername());
    				pstmt3.setString(2, review.getBookname());
    				pstmt3.setString(3, review.getReview());
    				pstmt3.setInt(4, 1);
    				pstmt3.executeUpdate();
    			}
    			//populate LikeBook table with users data from json file 
    			Collection<UserLikeBook> likes = loadLikes(cntx.getResourceAsStream(File.separator +	AppConstants.JSON_FILES+File.separator + AppConstants.LIKES_FILE));
    			PreparedStatement pstmt4 = conn.prepareStatement(AppConstants.INSERT_USER_BOOK_LIKE);
    			for (UserLikeBook like : likes){
    				pstmt4.setString(1, like.getUsername());
    				pstmt4.setString(2, like.getNickname()); 
    				pstmt4.setString(3, like.getBookname());    		   			
    				pstmt4.executeUpdate();
    			} 
    			//commit update
    			conn.commit();
    			//close statements
    			//pstmt.close();
    		}  		
    		//close connection
    		conn.close();

    	} catch (IOException | SQLException | NamingException e) {
    		//log error 
    		cntx.log("Error during database initialization",e);
    	}
    }
	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent event)  { 
    	 ServletContext cntx = event.getServletContext();
    	 
         //shut down database
    	 try {
     		//obtain ExampleDB data source from Tomcat's context and shutdown
     		Context context = new InitialContext();
     		BasicDataSource ds = (BasicDataSource)context.lookup(
     				cntx.getInitParameter(AppConstants.DB_DATASOURCE) + AppConstants.SHUTDOWN);
     		ds.getConnection();
     		ds = null;
		} catch (SQLException | NamingException e) {
			cntx.log("Error shutting down database",e);
		}

    }
    private Collection<User> loadUsers(InputStream is) throws IOException{
    	
    	//wrap input stream with a buffered reader to allow reading the file line by line
    	BufferedReader br = new BufferedReader(new InputStreamReader(is));
    	StringBuilder jsonFileContent = new StringBuilder();
    	//read line by line from file
    	String nextLine = null;
    	while ((nextLine = br.readLine()) != null){
    		jsonFileContent.append(nextLine);
    	}

    	Gson gson = new Gson();
    	//this is a require type definition by the Gson utility so Gson will 
    	//understand what kind of object representation should the json file match
    	Type type = new TypeToken<Collection<User>>(){}.getType();
    	Collection<User> users = gson.fromJson(jsonFileContent.toString(), type);
    	//close
    	br.close();	
    	return users;

    }
    private Collection<Book> loadBooks(InputStream is) throws IOException{
    	
    	//wrap input stream with a buffered reader to allow reading the file line by line
    	BufferedReader br = new BufferedReader(new InputStreamReader(is));
    	StringBuilder jsonFileContent = new StringBuilder();
    	//read line by line from file
    	String nextLine = null;
    	while ((nextLine = br.readLine()) != null){
    		jsonFileContent.append(nextLine);
    	}

    	Gson gson = new Gson();
    	//this is a require type definition by the Gson utility so Gson will 
    	//understand what kind of object representation should the json file match
    	Type type = new TypeToken<Collection<Book>>(){}.getType();
    	Collection<Book> books = gson.fromJson(jsonFileContent.toString(), type);
    	//close
    	br.close();	
    	return books;

    }
  private Collection<Review> loadReviews(InputStream is) throws IOException{
    	
    	//wrap input stream with a buffered reader to allow reading the file line by line
    	BufferedReader br = new BufferedReader(new InputStreamReader(is));
    	StringBuilder jsonFileContent = new StringBuilder();
    	//read line by line from file
    	String nextLine = null;
    	while ((nextLine = br.readLine()) != null){
    		jsonFileContent.append(nextLine);
    	}

    	Gson gson = new Gson();
    	//this is a require type definition by the Gson utility so Gson will 
    	//understand what kind of object representation should the json file match
    	Type type = new TypeToken<Collection<Review>>(){}.getType();
    	Collection<Review> reviews = gson.fromJson(jsonFileContent.toString(), type);
    	//close
    	br.close();	
    	return reviews;

    }
  private Collection<UserLikeBook> loadLikes(InputStream is) throws IOException{
  	
  	//wrap input stream with a buffered reader to allow reading the file line by line
  	BufferedReader br = new BufferedReader(new InputStreamReader(is));
  	StringBuilder jsonFileContent = new StringBuilder();
  	//read line by line from file
  	String nextLine = null;
  	while ((nextLine = br.readLine()) != null){
  		jsonFileContent.append(nextLine);
  	}

  	Gson gson = new Gson();
  	//this is a require type definition by the Gson utility so Gson will 
  	//understand what kind of object representation should the json file match
  	Type type = new TypeToken<Collection<UserLikeBook>>(){}.getType();
  	Collection<UserLikeBook> likes = gson.fromJson(jsonFileContent.toString(), type);
  	//close
  	br.close();	
  	return likes;

  }
}




