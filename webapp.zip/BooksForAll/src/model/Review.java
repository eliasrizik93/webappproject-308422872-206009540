package model;

/**
 * Review Class Hold All Review Information
 * @author elias
 *
 */

public class Review {
	int ID;
	String username;
	String bookname;
	String review;
	int verified;
	String photo;
	
	/**
	 * 
	 * @param ID The ID of the review
	 */
	public Review(int ID)
	{
		this.ID = ID;		
	}
	
	/**
	 * 
	 * @param ID ID of The Review
	 * @param username The Username Who Post The Review
	 * @param bookname The Bookname That The Review Post For
	 * @param review The Review
	 * @param verified If The Review Verified or Not
	 */
	public Review(int ID,String username,String bookname,String review,int verified)
	{
		this.ID = ID;
		this.username = username;
		this.bookname = bookname;
		this.review = review;
		this.verified = verified;
	}
	
	/**
	 * 
	 * @param ID ID of The Review
	 * @param username The Username Who Post The Review
	 * @param bookname The Bookname That The Review Post For
	 * @param review The Review
	 * @param verified If The Review Verified or Not
	 * @param photo Photo of The User That Posted The Review
	 */
	public Review(int ID,String username,String bookname,String review,int verified,String photo)
	{
		this.ID = ID;
		this.username = username;
		this.bookname = bookname;
		this.review = review;
		this.verified = verified;
		this.photo = photo;
	}
	
	/**
	 * 
	 * @param username The Username Who Post The Review
	 * @param bookname The Bookname That The Review Post For
	 * @param review The Review
	 * @param verified If The Review Verified or Not
	 */
		
	public Review(String username,String bookname,String review,int verified)
	{
		this.username = username;
		this.bookname = bookname;
		this.review = review;
	}
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public int getVerified() {
		return verified;
	}
	public void setVerified(int verified) {
		this.verified = verified;
	}
	
	
}
