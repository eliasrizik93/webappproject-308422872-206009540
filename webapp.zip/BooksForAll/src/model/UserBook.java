package model;

/**
 * Class For User Buy Book Relation
 * @author elias
 *
 */
public class UserBook {
	String username;
	String bookname;
	//String review;
	
	/**
	 * Constructor for By
	 * @param username The Username That Bought The Book
	 * @param bookName The Bookname
	 */
	public UserBook(String username,String bookName)
	{
		this.username = username;
		this.bookname = bookName;		
	}		
	/*
	public UserBook(String username,String bookname,String review)
	{
		this.username = username;
		this.bookname = bookname;
		this.review = review;		
	}	*/	
	
	public String getBookName() {
		return bookname;
	}

	public void setBookName(String bookName) {
		this.bookname = bookName;
	}

	/*public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}*/

	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getBook() {
		return bookname;
	}
	
	public void setBook(String bookname) {
		this.bookname = bookname;
	}
	
	
}
