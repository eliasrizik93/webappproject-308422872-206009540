package model;

/**
 * Class For User Information
 * @author elias
 *
 */
public class User {
	String username;
	String password;
	String nickname;
	String address;
	String email;
	String description;
	String photo;
	String telephone;
	
	/**
	 * This Constuctor to Register And Get User Full Information
	 * @param username The Username of The User
	 * @param email The Email of The User
	 * @param address The Address of The User
	 * @param telephone The Telephone of The User
	 * @param password The Password of The User
	 * @param nickname The Nickname of The User
	 * @param description The Description of The User 
	 * @param photo The Photo of The User
	 */
	public User(String username,String email,String address,String telephone,String password,String nickname,String description,String photo)
	{
		this.username = username;
		this.password = password;
		this.nickname = nickname;
		this.address = address;
		this.email = email;
		this.description = description;
		this.photo = photo;
		this.telephone = telephone;
	}
	
	/**
	 * This Constructor To Sign In
	 * @param username The User Username
	 * @param password The USer Password
	 */
	public User(String username,String password)
	{
		this.username = username;
		this.password = password;
	}	
	
	
	
	public User(String username)
	{
		this.username = username;
	}	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	
}
