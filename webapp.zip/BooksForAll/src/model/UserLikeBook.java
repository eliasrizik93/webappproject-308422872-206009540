package model;

/**
 * Class For User Like Book Action
 * @author elias
 *
 */
public class UserLikeBook {
	String username;
	String bookname;
	String nickname;

	/**
	 * 
	 * @param username The Username of The User
	 * @param bookname The Bookname of The User
	 * @param nickname The Nickname of The User
	 */
	public UserLikeBook(String username,String bookname,String nickname)
	{
		this.username = username;
		this.bookname = bookname;
		this.nickname = nickname;	
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getBookname() {
		return bookname;
	}


	public void setBookname(String bookname) {
		this.bookname = bookname;
	}


	public String getNickname() {
		return nickname;
	}


	public void setNickname(String nickname) {
		this.nickname = nickname;
	}	
	

	
}
