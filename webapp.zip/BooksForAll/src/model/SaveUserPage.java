package model;

/**
 * Class To Save Location of User In The Book
 * @author elias
 *
 */
public class SaveUserPage {
	String username;
	String bookname;
	double readLine;
	String url;
	
	/**
	 * Empty Constructor
	 */
	public SaveUserPage()
	{

	}
	
	/**
	 * 
	 * @param username username of the User That Reading The Book
	 * @param bookname The Bookname
	 * @param readLine The Line That The User Reach in The Book
	 */
	public SaveUserPage(String username,String bookname,int readLine)
	{
		this.username = username;
		this.bookname = bookname;
		this.readLine = readLine;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public double getReadLine() {
		return readLine;
	}

	public void setReadLine(double readLine) {
		this.readLine = readLine;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	
	
}
