package model;
/**
 *	Class For Book Information
 * @author elias
 *
 */
public class Book {
	String bookname;
	String image;
	double price;
	String description;
	int Likes;
	String url;
	
	/**
	 * Constructor For Book To Insert
	 * @param bookname The Name of The Book
	 * @param image The Image of The Book
	 * @param price The Price of The BOOK
	 * @param description The Description of The Book
	 * @param likes Numer of Likes
	 * @param url The url of The Book
	 */
	public Book(String bookname,String image,double price,String description,int likes,String url)
	{
		this.bookname = bookname;
		this.image = image;
		this.price = price;
		this.description = description;
		this.Likes = likes;		
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getLikes() {
		return Likes;
	}

	public void setLikes(int likes) {
		Likes = likes;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
